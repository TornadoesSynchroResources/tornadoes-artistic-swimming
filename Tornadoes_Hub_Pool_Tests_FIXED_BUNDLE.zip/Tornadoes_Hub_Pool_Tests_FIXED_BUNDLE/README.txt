TORNADOES HUB — STRUCTURE-CORRECTED POOL TESTS 9–15

This build fixes the section wrapper so Gym Tests 1–8 and Pool Tests 9–15 stay together inside the hidden/visible `section-testing` tab. The roster remains a separate sibling section, and `section-wa-rules` begins after testing closes.

Pool Testing cards 9–15 use the seven image files in `pool-testing-assets/`. Upload the entire folder with index.html and preserve the folder name.

IMPORTANT: The source HTML still references these eight Gym Testing image files, but they were NOT present in the uploaded source/package used to prepare this build:
- push-ups-testing.png
- v-ups-testing.png
- frog-jumps-testing.png
- back-arch-hold-testing.png
- shoulder-twist-rope-testing.png
- bridge-testing.png
- splits-testing.png
- folding-forward-testing.png

Those eight images must be restored from the existing project or supplied before the old Gym Test photos can display. Do not rename unrelated Pool Testing images to these names; that would show the wrong exercise.

This package is not published to GitHub/Vercel automatically.
